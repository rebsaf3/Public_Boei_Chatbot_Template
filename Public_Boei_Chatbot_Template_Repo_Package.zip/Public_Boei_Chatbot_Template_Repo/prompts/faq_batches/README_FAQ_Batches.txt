FAQ batch import guide

Use batches of ten items per prompt.
Review generated items before saving.
Include pinned FAQs for hotline accuracy and no staff connection.
